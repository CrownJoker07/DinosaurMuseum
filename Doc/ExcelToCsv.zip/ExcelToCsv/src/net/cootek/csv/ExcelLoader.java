/*     */ package net.cootek.csv;
/*     */ 
/*     */ import java.io.File;
/*     */ import java.text.DateFormat;
/*     */ import java.text.DecimalFormat;
/*     */ import java.text.SimpleDateFormat;
/*     */ import java.util.ArrayList;
/*     */ import java.util.HashMap;
/*     */ import java.util.List;
/*     */ import javax.swing.JOptionPane;
/*     */ import org.apache.poi.hssf.usermodel.HSSFCell;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ExcelLoader
/*     */ {
/*  18 */   public static final DateFormat DEFAULT_DATE_FORMAT = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
/*     */ 
/*     */   
/*     */   public static void main(String[] args) {
/*  22 */     String path1 = "/Users/harry/Documents/work/GBGame/Dragon/Doc/excel";
/*  23 */     String path2 = "/Users/harry/Documents/work/GBGame/Dragon/Doc/excel_output/csv/";
/*  24 */     String path3 = "/Users/harry/Documents/work/GBGame/Dragon/Doc/attributeType.config";
/*  25 */     if (args != null) {
/*  26 */       if (args.length > 0) {
/*  27 */         path1 = args[0];
/*     */       }
/*  29 */       if (args.length > 1) {
/*  30 */         path2 = args[1];
/*     */       }
/*  32 */       if (args.length > 2) {
/*  33 */         path3 = args[2];
/*     */       }
/*     */     } 
/*     */     
/*  37 */     loadExcels2(path1, path2, path3);
/*     */   }
/*     */ 
/*     */   
/*     */   public static void loadExcels2(String path1, String path2, String path3) {
/*  42 */     HashMap<Object, Object> keys = null;
/*  43 */     if (path3 == null || !(new File(path3)).exists()) {
/*  44 */       keys = new HashMap<>();
/*     */     } else {
/*  46 */       keys = (HashMap)XMLUtils.loadKeys(path3);
/*     */     } 
/*     */     
/*  49 */     File file1 = new File(path1);
/*  50 */     File file2 = new File(path2);
/*  51 */     if (!file2.exists()) {
/*  52 */       System.out.println("file2.mkdirs()");
/*  53 */       file2.mkdirs();
/*     */     } 
/*     */     
/*  56 */     File[] flistTemp = file1.listFiles();
/*  57 */     List<File> flist = new ArrayList();
/*  58 */     for (int i = 0; i < flistTemp.length; i++) {
/*  59 */       File fi = flistTemp[i];
/*  60 */       if (fi.getName().endsWith(".xls") || fi.getName().endsWith(".xlsx")) {
/*  61 */         flist.add(fi);
/*     */       }
/*     */     } 
/*     */     
/*  65 */     System.err.println("总文件数=" + flist.size());
/*  66 */     System.err.println("输入路径=" + path1);
/*  67 */     System.err.println("输出路径=" + path2);
/*     */     
/*  69 */     int countOk = 0;
/*  70 */     int countError = 0;
/*  71 */     StringBuffer sberr = null;
/*  72 */     for (int j = 0; j < flist.size(); j++) {
/*  73 */       File fi = flist.get(j);
/*  74 */       System.err.println("进度:" + (j + 1) + "/" + flist.size() + "/" + fi.getName());
/*  75 */       if (fi.getName().endsWith(".xls") || fi.getName().endsWith(".xlsx"))
/*     */       {
/*     */ 
/*     */         
/*  79 */         if (fi.getName().endsWith("exceptionCode.xls")) {
/*  80 */           System.out.println("这个文件客户端不需要:" + fi.getName());
/*     */         }
/*     */         else {
/*     */           
/*  84 */           StringBuffer sb = new StringBuffer();
/*     */           
/*     */           try {
/*  87 */             String fileName = fi.getName().substring(0, fi.getName().indexOf("."));
/*  88 */             ExcelUtils.loadExcelWtihColumnName(fi.getName(), fi.getAbsolutePath(), sb, (String[])keys.get(fileName));
/*     */             
/*  90 */             List<String> outStrs = new ArrayList();
/*  91 */             outStrs.add(sb.toString());
/*     */             if (fi.getName().endsWith(".xlsx")) {
	/*  93 */             FileUtils.saveChatTxt(sb.toString(), String.valueOf(path2) + fi.getName().replace(".xlsx", ".csv"));
					  }else
					  {
	/*  93 */             FileUtils.saveChatTxt(sb.toString(), String.valueOf(path2) + fi.getName().replace(".xls", ".csv"));
					  }
/*     */             
/*  95 */             countOk++;
/*  96 */           } catch (Exception e) {
/*  97 */             if (sberr == null) {
/*  98 */               sberr = new StringBuffer();
/*  99 */               sberr.append(fi.getName());
/*     */             } else {
/* 101 */               sberr.append("," + fi.getName());
/*     */             } 
/*     */             
/* 104 */             System.err.println("加载excel文件失败:" + fi.getName());
/* 105 */             e.printStackTrace();
/* 106 */             countError++;
/*     */           } 
/*     */         }  } 
/*     */     } 
/* 110 */     System.err.println("处理完成,成功导出的数量:" + countOk + ",失败的数量:" + countError);
/*     */     
/* 112 */     if (countError > 0) {
/* 113 */       String err = "加载文件有错,请查看错误日志,失败的数量:" + countError + ",分别是:" + sberr.toString();
/* 114 */       JOptionPane.showMessageDialog(null, err, "警告", 0);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   private static String getCellValueTypeName(String fag) {
/* 120 */     String type = null;
/* 121 */     if (fag.startsWith("str")) {
/* 122 */       type = "String";
/* 123 */     } else if (fag.startsWith("date_") || fag.startsWith("time_")) {
/* 124 */       type = "Date";
/*     */     } else {
/* 126 */       type = "Integer";
/*     */     } 
/*     */     
/* 129 */     return type;
/*     */   }
/*     */ 
/*     */   
/*     */   public static String getCellValue2String(HSSFCell cell) {
/* 134 */     if (cell == null) {
/* 135 */       return null;
/*     */     }
/*     */     
/* 138 */     int dataFormat = cell.getCellStyle().getDataFormat();
/*     */     
/* 140 */     if (dataFormat == 14 || dataFormat == 178 || dataFormat == 180 || 
/* 141 */       dataFormat == 181 || dataFormat == 182 || 
/* 142 */       dataFormat == 183 || dataFormat == 185) {
/* 143 */       String str = getDateValue(cell);
/*     */       
/* 145 */       return str;
/*     */     } 
/*     */     
/* 148 */     String value = null;
/* 149 */     switch (cell.getCellType().ordinal()) {
/*     */       
/*     */       case 0:
/* 152 */         value = (new DecimalFormat("0.##########")).format(cell.getNumericCellValue());
/*     */         break;
/*     */       case 1:
/* 155 */         value = cell.getRichStringCellValue().toString();
/*     */         break;
/*     */       case 2:
/* 158 */         value = String.valueOf(cell.getCellFormula());
/*     */         break;
/*     */       case 3:
/* 161 */         value = String.valueOf(cell.getRichStringCellValue().toString());
/*     */         break;
/*     */       case 4:
/* 164 */         value = String.valueOf(cell.getBooleanCellValue());
/*     */         break;
/*     */       case 5:
/* 167 */         value = String.valueOf(cell.getErrorCellValue());
/*     */         break;
/*     */     } 
/* 170 */     return value;
/*     */   }
/*     */ 
/*     */   
/*     */   public static Object getCellValueObject(HSSFCell cell, String titleType) {
/* 175 */     if (cell == null) {
/* 176 */       return null;
/*     */     }
/*     */     
/* 179 */     Object obj = null;
/* 180 */     String typeName = getCellValueTypeName(titleType);
/* 181 */     if (typeName.endsWith("Date")) {
/* 182 */       obj = cell.getDateCellValue();
/* 183 */     } else if (typeName.endsWith("Integer")) {
/* 184 */       obj = ExcelUtils.getIntValue(cell);
/* 185 */     } else if (typeName.endsWith("String")) {
/* 186 */       obj = cell.toString();
/*     */     } else {
/* 188 */       obj = cell.toString();
/* 189 */       System.err.println("getCellValue2String:未知数值类型=" + obj);
/*     */     } 
/*     */     
/* 192 */     return obj;
/*     */   }
/*     */ 
/*     */   
/*     */   private static String getDateValue(HSSFCell cell) {
/* 197 */     return DEFAULT_DATE_FORMAT.format(cell.getDateCellValue());
/*     */   }
/*     */ }


/* Location:              /Users/harry/Documents/work/GBGame/Dragon/Doc/ExcelToCsv.jar!/net/cootek/csv/ExcelLoader.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */