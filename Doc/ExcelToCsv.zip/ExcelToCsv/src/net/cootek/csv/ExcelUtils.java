/*     */ package net.cootek.csv;
/*     */ 
/*     */ import java.io.FileInputStream;
/*     */ import java.io.IOException;
/*     */ import java.text.DateFormat;
/*     */ import java.text.SimpleDateFormat;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Date;
/*     */ import java.util.HashSet;
/*     */ import java.util.List;
/*     */ import org.apache.poi.hssf.usermodel.HSSFCell;
/*     */ import org.apache.poi.hssf.usermodel.HSSFRow;
/*     */ import org.apache.poi.hssf.usermodel.HSSFSheet;
/*     */ import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellType;
import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
/*     */ 
/*     */ 
/*     */ public class ExcelUtils
/*     */ {
/*  19 */   public static final DateFormat DEFAULT_DATE_FORMAT = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
/*     */   public static final String DATA_SEP = "|";
/*  21 */   static int i0 = 48;
/*  22 */   static int i9 = 57;
/*     */ 
/*     */   
/*     */   public static Integer getIntValue(Cell cell) {
/*  26 */     int val = -1;
/*  27 */     if (cell.getCellType() == CellType.NUMERIC) {
/*  28 */       Double dou = Double.valueOf(cell.getNumericCellValue());
/*  29 */       val = dou.intValue();
/*     */     } else {
/*  31 */       String cellStr = cell.toString().trim();
				if(cellStr.length() <= 0) {
					
					return 0;
				}
/*  32 */       if (cellStr.indexOf('.') > 0) {
/*  33 */         Double dou = Double.valueOf(Double.parseDouble(cellStr));
/*  34 */         val = dou.intValue();
/*     */       } else {
/*  36 */         val = Integer.parseInt(cellStr);
/*     */       } 
/*     */     } 
/*  39 */     return Integer.valueOf(val);
/*     */   }
/*     */ 
/*     */   
/*     */   public static void loadExcelXLSXWtihColumnName(String fileName, String absPath, StringBuffer stringBuffer, String[] checkKeys) {
/*  44 */     XSSFWorkbook hssfWorkbook = null;
/*     */     try {
/*  46 */       hssfWorkbook = new XSSFWorkbook(new FileInputStream(absPath));
/*  47 */     } catch (IOException e1) {
/*  48 */       throw new RuntimeException(e1);
/*     */     } 
/*     */     
/*  51 */     XSSFSheet hssfSheet = hssfWorkbook.getSheetAt(0);
/*  52 */     if (hssfSheet == null) {
/*  53 */       throw new RuntimeException("第一个sheet 不存在");
/*     */     }
/*     */     
/*  56 */     XSSFRow hssfRowTitle = hssfSheet.getRow(0);
/*  57 */     if (hssfRowTitle == null) {
/*  58 */       throw new RuntimeException("列标题不存在");
/*     */     }
/*     */     
/*  61 */     XSSFRow hssfRowType = hssfSheet.getRow(1);
/*  62 */     if (hssfRowType == null) {
/*  63 */       throw new RuntimeException("类型不存在");
/*     */     }
/*     */     
/*  66 */     List<String> columnNames = new ArrayList();
/*  67 */     int maxCellNum = 0;
/*     */     
/*  69 */     stringBuffer.append("#|");
/*  70 */     for (int i = 0; i <= hssfRowTitle.getLastCellNum(); i++) {
/*  71 */       XSSFCell xh = hssfRowTitle.getCell(i);
/*  72 */       if (xh == null || xh.toString().trim().length() == 0) {
/*  73 */         maxCellNum = i;
/*     */         break;
/*     */       } 
/*  76 */       columnNames.add(xh.toString().trim());
/*     */       
/*  78 */       if (i < hssfRowTitle.getLastCellNum() - 1) {
/*  79 */         stringBuffer.append(String.valueOf(xh.toString()) + "|");
/*     */       } else {
/*  81 */         stringBuffer.append(xh.toString());
/*     */       } 
/*     */     } 
/*  84 */     stringBuffer.append("\n");
/*     */     
/*  86 */     stringBuffer.append("#|");
/*  87 */     List<String> columnTypes = new ArrayList();
/*  88 */     for (int j = 0; j < maxCellNum; j++) {
/*  89 */       XSSFCell xh = hssfRowType.getCell(j);
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*  94 */       columnTypes.add(xh.toString().trim());
/*     */       
/*  96 */       if (j < hssfRowTitle.getLastCellNum() - 1) {
/*  97 */         stringBuffer.append(String.valueOf(xh.toString()) + "|");
/*     */       } else {
/*  99 */         stringBuffer.append(xh.toString());
/*     */       } 
/*     */     } 
/*     */     
/* 103 */     HashSet<String> idKey = new HashSet();
/*     */     
/* 105 */     int ccc = 0;
/* 106 */     for (int rowNum = 3; rowNum <= hssfSheet.getLastRowNum(); rowNum++) {
/* 107 */       XSSFRow hssfRow = hssfSheet.getRow(rowNum);
/*     */       
/* 109 */       if (hssfRow == null)
/*     */         break; 
/* 111 */       if (hssfRow.getCell(0) == null) {
/*     */         break;
/*     */       }
/* 114 */       Object obj0 = null;
/*     */       try {
/* 116 */         obj0 = getCellValueObject(hssfRow.getCell(0), columnTypes.get(0));
/* 117 */       } catch (Exception e) {
/* 118 */         e.printStackTrace();
/*     */       } 
/*     */       
/* 121 */       if (obj0 == null || obj0.toString().length() < 1) {
/* 122 */         System.out.println("有空数据:" + absPath);
/*     */         
/*     */         break;
/*     */       } 
/* 126 */       if (fileName.startsWith("translation_")) {
/* 127 */         int iii = 1;
/* 128 */         XSSFCell xh = hssfRow.getCell(iii);
/* 129 */         String columnName = columnNames.get(iii);
/* 130 */         String columnType = columnTypes.get(iii);
/* 131 */         Object obj = null;
/*     */         try {
/* 133 */           obj = getCellValueObject(xh, columnType);
/* 134 */         } catch (Exception e) {
/* 135 */           throw new RuntimeException(String.valueOf(absPath) + ":" + columnName + " row:" + rowNum + " 数据错误:" + e.toString());
/*     */         } 
/*     */         
/* 138 */         String str = obj.toString();
/* 139 */         if (str.startsWith("exceptionCode")) {
/* 140 */           ccc++;
/*     */         }
/*     */       }
/*     */       else {
/*     */         
/* 145 */         stringBuffer.append("\n");
/*     */         
/* 147 */         StringBuffer rowKeyStr = new StringBuffer();
/* 148 */         stringBuffer.append("|");
/* 149 */         for (int k = 0; k < maxCellNum; k++) {
/* 150 */           XSSFCell xh = hssfRow.getCell(k);
/* 151 */           String columnName = columnNames.get(k);
/* 152 */           String columnType = columnTypes.get(k);
/* 153 */           Object obj = null;
/*     */           try {
/* 155 */             obj = getCellValueObject(xh, columnType);
/* 156 */           } catch (Exception e) {
/* 157 */             throw new RuntimeException(String.valueOf(absPath) + ":" + columnName + " row:" + rowNum + " 数据错误:" + e.toString());
/*     */           } 
/*     */           
/* 160 */           String str = null;
/* 161 */           if (obj instanceof Date) {
/* 162 */             String dataStr = DEFAULT_DATE_FORMAT.format((Date)obj);
/* 163 */             str = dataStr;
/*     */           } else {
/* 165 */             str = obj.toString();
/*     */           } 
/*     */           
/* 168 */           str = str.trim().replace("\n", "");
/* 169 */           str = str.trim().replace("|", "");
/*     */           
/* 171 */           if (k < maxCellNum - 1) {
/* 172 */             stringBuffer.append(String.valueOf(str) + "|");
/*     */           } else {
/* 174 */             stringBuffer.append(str);
/*     */           } 
/*     */           
/* 177 */           if (checkKeys != null && checkKeys.length > 0) {
/*     */             String[] arrayOfString;
/* 179 */             int m = (arrayOfString = checkKeys).length;
/* 180 */             for (int n = 0; k < m; ) { String checkKey = arrayOfString[n];
/* 181 */               if (checkKey.equals(columnName))
/* 182 */                 rowKeyStr.append(String.valueOf(str) + "_"); 
/*     */               n++; }
/*     */           
/* 185 */           } else if ("Id".equals(columnName)) {
/* 186 */             rowKeyStr.append(String.valueOf(str) + "_");
/*     */           } 
/*     */         } 
/*     */         
/* 190 */         if (idKey.contains(rowKeyStr.toString())) {
/* 191 */           System.err.println("导出异常,检测到重复的key!!!path=" + absPath + ", row:" + rowNum + ",重复的key=" + rowKeyStr.toString());
/* 192 */           throw new RuntimeException();
/*     */         } 
/* 194 */         idKey.add(rowKeyStr.toString());
/*     */       } 
/*     */     } 
/*     */     
/* 198 */     if (ccc > 0) {
/* 199 */       System.out.println("\t有数据不用导出,fileName=" + fileName + ",跳过的行数:" + ccc);
/*     */     }
/*     */   }
/*     */   public static void loadExcelXLSWtihColumnName(String fileName, String absPath, StringBuffer stringBuffer, String[] checkKeys) {
	/*  44 */     HSSFWorkbook hssfWorkbook = null;
	/*     */     try {
	/*  46 */       hssfWorkbook = new HSSFWorkbook(new FileInputStream(absPath));
	/*  47 */     } catch (IOException e1) {
	/*  48 */       throw new RuntimeException(e1);
	/*     */     } 
	/*     */     
	/*  51 */     HSSFSheet hssfSheet = hssfWorkbook.getSheetAt(0);
	/*  52 */     if (hssfSheet == null) {
	/*  53 */       throw new RuntimeException("第一个sheet 不存在");
	/*     */     }
	/*     */     
	/*  56 */     HSSFRow hssfRowTitle = hssfSheet.getRow(0);
	/*  57 */     if (hssfRowTitle == null) {
	/*  58 */       throw new RuntimeException("列标题不存在");
	/*     */     }
	/*     */     
	/*  61 */     HSSFRow hssfRowType = hssfSheet.getRow(1);
	/*  62 */     if (hssfRowType == null) {
	/*  63 */       throw new RuntimeException("类型不存在");
	/*     */     }
	/*     */     
	/*  66 */     List<String> columnNames = new ArrayList();
	/*  67 */     int maxCellNum = 0;
	/*     */     
	/*  69 */     stringBuffer.append("#|");
	/*  70 */     for (int i = 0; i <= hssfRowTitle.getLastCellNum(); i++) {
	/*  71 */       HSSFCell xh = hssfRowTitle.getCell(i);
	/*  72 */       if (xh == null || xh.toString().trim().length() == 0) {
	/*  73 */         maxCellNum = i;
	/*     */         break;
	/*     */       } 
	/*  76 */       columnNames.add(xh.toString().trim());
	/*     */       
	/*  78 */       if (i < hssfRowTitle.getLastCellNum() - 1) {
	/*  79 */         stringBuffer.append(String.valueOf(xh.toString()) + "|");
	/*     */       } else {
	/*  81 */         stringBuffer.append(xh.toString());
	/*     */       } 
	/*     */     } 
	/*  84 */     stringBuffer.append("\n");
	/*     */     
	/*  86 */     stringBuffer.append("#|");
	/*  87 */     List<String> columnTypes = new ArrayList();
	/*  88 */     for (int j = 0; j < maxCellNum; j++) {
	/*  89 */       HSSFCell xh = hssfRowType.getCell(j);
	/*     */ 
	/*     */ 
	/*     */ 
	/*     */       
	/*  94 */       columnTypes.add(xh.toString().trim());
	/*     */       
	/*  96 */       if (j < hssfRowTitle.getLastCellNum() - 1) {
	/*  97 */         stringBuffer.append(String.valueOf(xh.toString()) + "|");
	/*     */       } else {
	/*  99 */         stringBuffer.append(xh.toString());
	/*     */       } 
	/*     */     } 
	/*     */     
	/* 103 */     HashSet<String> idKey = new HashSet();
	/*     */     
	/* 105 */     int ccc = 0;
	/* 106 */     for (int rowNum = 3; rowNum <= hssfSheet.getLastRowNum(); rowNum++) {
	/* 107 */       HSSFRow hssfRow = hssfSheet.getRow(rowNum);
	/*     */       
	/* 109 */       if (hssfRow == null)
	/*     */         break; 
	/* 111 */       if (hssfRow.getCell(0) == null) {
	/*     */         break;
	/*     */       }
	/* 114 */       Object obj0 = null;
	/*     */       try {
	/* 116 */         obj0 = getCellValueObject(hssfRow.getCell(0), columnTypes.get(0));
	/* 117 */       } catch (Exception e) {
	/* 118 */         e.printStackTrace();
	/*     */       } 
	/*     */       
	/* 121 */       if (obj0 == null || obj0.toString().length() < 1) {
	/* 122 */         System.out.println("有空数据:" + absPath);
	/*     */         
	/*     */         break;
	/*     */       } 
	/* 126 */       if (fileName.startsWith("translation_")) {
	/* 127 */         int iii = 1;
	/* 128 */         HSSFCell xh = hssfRow.getCell(iii);
	/* 129 */         String columnName = columnNames.get(iii);
	/* 130 */         String columnType = columnTypes.get(iii);
	/* 131 */         Object obj = null;
	/*     */         try {
	/* 133 */           obj = getCellValueObject(xh, columnType);
	/* 134 */         } catch (Exception e) {
	/* 135 */           throw new RuntimeException(String.valueOf(absPath) + ":" + columnName + " row:" + rowNum + " 数据错误:" + e.toString());
	/*     */         } 
	/*     */         
	/* 138 */         String str = obj.toString();
	/* 139 */         if (str.startsWith("exceptionCode")) {
	/* 140 */           ccc++;
	/*     */         }
	/*     */       }
	/*     */       else {
	/*     */         
	/* 145 */         stringBuffer.append("\n");
	/*     */         
	/* 147 */         StringBuffer rowKeyStr = new StringBuffer();
	/* 148 */         stringBuffer.append("|");
	/* 149 */         for (int k = 0; k < maxCellNum; k++) {
	/* 150 */           HSSFCell xh = hssfRow.getCell(k);
	/* 151 */           String columnName = columnNames.get(k);
	/* 152 */           String columnType = columnTypes.get(k);
	/* 153 */           Object obj = null;
	/*     */           try {
	/* 155 */             obj = getCellValueObject(xh, columnType);
	/* 156 */           } catch (Exception e) {
	/* 157 */             throw new RuntimeException(String.valueOf(absPath) + ":" + columnName + " row:" + rowNum + " 数据错误:" + e.toString());
	/*     */           } 
	/*     */           
	/* 160 */           String str = null;
	/* 161 */           if (obj instanceof Date) {
	/* 162 */             String dataStr = DEFAULT_DATE_FORMAT.format((Date)obj);
	/* 163 */             str = dataStr;
	/*     */           } else {
	/* 165 */             str = obj.toString();
	/*     */           } 
	/*     */           
	/* 168 */           str = str.trim().replace("\n", "");
	/* 169 */           str = str.trim().replace("|", "");
	/*     */           
	/* 171 */           if (k < maxCellNum - 1) {
	/* 172 */             stringBuffer.append(String.valueOf(str) + "|");
	/*     */           } else {
	/* 174 */             stringBuffer.append(str);
	/*     */           } 
	/*     */           
	/* 177 */           if (checkKeys != null && checkKeys.length > 0) {
	/*     */             String[] arrayOfString;
	/* 179 */             int m = (arrayOfString = checkKeys).length;
	/* 180 */             for (int n = 0; k < m; ) { String checkKey = arrayOfString[n];
	/* 181 */               if (checkKey.equals(columnName))
	/* 182 */                 rowKeyStr.append(String.valueOf(str) + "_"); 
	/*     */               n++; }
	/*     */           
	/* 185 */           } else if ("Id".equals(columnName)) {
	/* 186 */             rowKeyStr.append(String.valueOf(str) + "_");
	/*     */           } 
	/*     */         } 
	/*     */         
	/* 190 */         if (idKey.contains(rowKeyStr.toString())) {
	/* 191 */           System.err.println("导出异常,检测到重复的key!!!path=" + absPath + ", row:" + rowNum + ",重复的key=" + rowKeyStr.toString());
	/* 192 */           throw new RuntimeException();
	/*     */         } 
	/* 194 */         idKey.add(rowKeyStr.toString());
	/*     */       } 
	/*     */     } 
	/*     */     
	/* 198 */     if (ccc > 0) {
	/* 199 */       System.out.println("\t有数据不用导出,fileName=" + fileName + ",跳过的行数:" + ccc);
	/*     */     }
	/*     */   }
/*     */   public static void loadExcelWtihColumnName(String fileName, String absPath, StringBuffer stringBuffer, String[] checkKeys) {
	/*  44 */    	if(fileName.endsWith(".xlsx")) {
						loadExcelXLSXWtihColumnName(fileName,absPath,stringBuffer,checkKeys);
		
					}else {
						loadExcelXLSWtihColumnName(fileName,absPath,stringBuffer,checkKeys);		
					}
	/*     */   }

/*     */   public static Object getCellValueObject(Cell cell, String titleType) {
/* 204 */     if (cell == null) {
/* 205 */       throw new RuntimeException("传入的cell 为空");
/*     */     }
/*     */     
/* 208 */     String typeName = getCellValueTypeName(titleType);
/*     */     
/* 210 */     if (typeName.endsWith("Date"))
/* 211 */       return cell.getDateCellValue(); 
/* 212 */     if (typeName.endsWith("Integer"))
/* 213 */       return getIntValue(cell); 
/* 214 */     if (typeName.endsWith("String")) {
/* 215 */       String str = cell.toString();
				if(str.equals("-1.0") || str.equals("-1")) {
					str = "-1.0";
					System.out.println("\t 字符串类型命中=" + str);
				}
/* 216 */       String newStr = null;
/* 217 */       if (isIntNumber(str)) {
/* 218 */         double dou = Double.parseDouble(str);
/* 219 */         int i = (int)dou;
				
/* 220 */         newStr = (new StringBuilder(String.valueOf(i))).toString();
/*     */       } else {
/* 222 */         newStr = str;
/*     */       } 
/*     */       
/* 225 */       return newStr;
/*     */     } 
/* 227 */     return cell.toString();
/*     */   }

			
/*     */ 
/*     */   
/*     */   private static boolean isIntNumber(String str) {
/* 232 */     if (str == null || str.length() < 1) {
/* 233 */       return false;
/*     */     }
/*     */     
/* 236 */     int countPoint = 0;
/* 237 */     for (int i = 0; i < str.length(); i++) {
/* 238 */       char ch = str.charAt(i);
/* 239 */       if (ch == '.') {
/* 240 */         countPoint++;
/*     */       }
/* 242 */       else if (ch > i9 || ch < i0) {
/* 243 */         return false;
/*     */       } 
/*     */     } 
/*     */     
/* 247 */     if (countPoint > 1) {
/* 248 */       return false;
/*     */     }
/*     */     
/* 251 */     double dou = Double.parseDouble(str);
/* 252 */     int j = (int)dou;
/*     */     
/* 254 */     return (dou == j);
/*     */   }
/*     */ 
/*     */   
/*     */   private static String getCellValueTypeName(String fag) {
/* 259 */     String type = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 268 */     if (fag.equals("int")) {
/* 269 */       type = "Integer";
/*     */     } else {
/* 271 */       type = "String";
/*     */     } 
/* 273 */     return type;
/*     */   }
/*     */ 
/*     */   
/*     */   public static void main(String[] args) {
/* 278 */     StringBuffer buffer = new StringBuffer();
/*     */     try {
/* 280 */       String name = "achievement.xls";
///* 281 */       loadExcelWtihColumnName(name, "E:\\world2\\game-server\\res\\excel\\" + name, buffer, null);
/* 282 */     } catch (Exception e) {
/* 283 */       e.printStackTrace();
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public static class RowData
/*     */   {
/*     */     private final List<String> columnNames;
/*     */     private List<Object> columnValues;
/*     */     
/*     */     public RowData(List<String> columnNames) {
/* 294 */       this.columnNames = columnNames;
/*     */     }
/*     */     
/*     */     public List<String> getColumnNames() {
/* 298 */       return this.columnNames;
/*     */     }
/*     */     
/*     */     public List<Object> getColumnValues() {
/* 302 */       return this.columnValues;
/*     */     }
/*     */     
/*     */     public void setColumnValues(List<Object> columnValues) {
/* 306 */       this.columnValues = columnValues;
/*     */     }
/*     */   }
/*     */ }


/* Location:              /Users/harry/Documents/work/GBGame/Dragon/Doc/ExcelToCsv.jar!/net/cootek/csv/ExcelUtils.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */