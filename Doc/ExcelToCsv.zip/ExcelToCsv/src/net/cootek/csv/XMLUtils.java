/*     */ package net.cootek.csv;
/*     */ 
/*     */ import java.io.File;
/*     */ import java.io.IOException;
/*     */ import java.util.ArrayList;
/*     */ import java.util.HashMap;
/*     */ import javax.xml.parsers.DocumentBuilder;
/*     */ import javax.xml.parsers.DocumentBuilderFactory;
/*     */ import javax.xml.parsers.ParserConfigurationException;
/*     */ import org.w3c.dom.Document;
/*     */ import org.w3c.dom.Element;
/*     */ import org.w3c.dom.Node;
/*     */ import org.w3c.dom.NodeList;
/*     */ import org.xml.sax.SAXException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class XMLUtils
/*     */ {
/*     */   public static Element getElementMyXML(String path) {
/*  22 */     Element element = null;
/*  23 */     File file = new File(path);
/*  24 */     if (!file.exists()) {
/*  25 */       return null;
/*     */     }
/*     */     
/*  28 */     DocumentBuilder db = null;
/*  29 */     DocumentBuilderFactory dbf = null;
/*     */     
/*     */     try {
/*  32 */       dbf = DocumentBuilderFactory.newInstance();
/*     */       
/*  34 */       db = dbf.newDocumentBuilder();
/*     */       
/*  36 */       Document dt = db.parse(file);
/*     */       
/*  38 */       element = dt.getDocumentElement();
/*     */     }
/*  40 */     catch (SAXException e) {
/*  41 */       e.printStackTrace();
/*  42 */     } catch (IOException e) {
/*  43 */       e.printStackTrace();
/*  44 */     } catch (ParserConfigurationException e) {
/*  45 */       e.printStackTrace();
/*     */     } 
/*  47 */     return element;
/*     */   }
/*     */ 
/*     */   
/*     */   public static ArrayList<Node> getAllChildNodesMyXML(NodeList fatherNode) {
/*  52 */     ArrayList<Node> al = new ArrayList();
/*     */     
/*  54 */     for (int i = 0; i < fatherNode.getLength(); i++) {
/*  55 */       Node childNode = fatherNode.item(i);
/*     */       
/*  57 */       if (!"#text".equals(childNode.getNodeName()))
/*     */       {
/*     */ 
/*     */         
/*  61 */         al.add(childNode); } 
/*     */     } 
/*  63 */     return al;
/*     */   }
/*     */ 
/*     */   
/*     */   public static ArrayList<Node> getChildNodesMyXML(NodeList fatherNode, String name) {
/*  68 */     ArrayList<Node> al = new ArrayList();
/*     */     
/*  70 */     for (int i = 0; i < fatherNode.getLength(); i++) {
/*  71 */       Node childNode = fatherNode.item(i);
/*     */       
/*  73 */       if (name.equals(childNode.getNodeName()))
/*     */       {
/*  75 */         al.add(childNode);
/*     */       }
/*     */     } 
/*  78 */     return al;
/*     */   }
/*     */ 
/*     */   
/*     */   public static ArrayList<Node> getChildNodesMyXMLAttributes(NodeList fatherNode, String attributes, String name) {
/*  83 */     ArrayList<Node> al = new ArrayList();
/*     */     
/*  85 */     for (int i = 0; i < fatherNode.getLength(); i++) {
/*  86 */       Node childNode = fatherNode.item(i);
/*  87 */       System.out.println(childNode.getNodeName());
/*     */       
/*     */       try {
/*  90 */         if (!name.equals(childNode.getAttributes().getNamedItem(
/*  91 */               attributes).getNodeValue()))
/*     */           break; 
/*  93 */         al.add(childNode);
/*     */ 
/*     */ 
/*     */       
/*     */       }
/*  98 */       catch (NullPointerException nullPointerException) {}
/*     */     } 
/*     */ 
/*     */     
/* 102 */     return al;
/*     */   }
/*     */ 
/*     */   
/*     */   public static HashMap<String, String[]> loadKeys(String path) {
/* 107 */     Element element = getElementMyXML(path);
/*     */     
/* 109 */     HashMap<Object, Object> all = new HashMap<>();
/*     */     
/* 111 */     System.out.println("加载key定义表:path=" + path);
/* 112 */     NodeList fatherNode = element.getChildNodes();
/*     */     
/* 114 */     ArrayList<Node> arrayList = getAllChildNodesMyXML(fatherNode);
/* 115 */     System.out.println("arrayList.size=" + arrayList.size());
/* 116 */     for (int i = 0; i < arrayList.size(); i++) {
/* 117 */       Node no = arrayList.get(i);
/*     */       
/* 119 */       if (no.getNodeName().equals("table")) {
/* 120 */         String fileName = no.getAttributes().getNamedItem("file").getNodeValue();
/* 121 */         fileName = fileName.substring(0, fileName.indexOf("."));
/*     */         
/* 123 */         String keyStr = no.getAttributes().getNamedItem("key").getNodeValue();
/* 124 */         String[] keys = keyStr.split(",");
/*     */         
/* 126 */         System.out.println("表名:" + fileName + "\t\t\t keys=" + keyStr);
/*     */         
/* 128 */         all.put(fileName, keys);
/*     */       } else {
/* 130 */         System.out.println("未识别的Node:" + no.getNodeName());
/*     */       } 
/*     */     } 
/*     */     
/* 134 */     return (HashMap)all;
/*     */   }
/*     */ 
/*     */   
/*     */   public static void main(String[] args) {
/* 139 */     String path = "E:\\pan\\work\\goodworld2\\world2_svn_203\\trunk\\docs\\attributeType.config";
/* 140 */     loadKeys(path);
/*     */   }
/*     */ }


/* Location:              /Users/harry/Documents/work/GBGame/Dragon/Doc/ExcelToCsv.jar!/net/cootek/csv/XMLUtils.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */