/*    */ package net.cootek.csv;
/*    */ 
/*    */ import java.io.File;
/*    */ import java.io.FileNotFoundException;
/*    */ import java.io.IOException;
/*    */ import java.io.PrintWriter;
/*    */ 
/*    */ 
/*    */ public class FileUtils
/*    */ {
/*    */   public static boolean saveChatTxt(String str, String path) {
/* 12 */     boolean ok = false;
/* 13 */     File fo = null;
/* 14 */     PrintWriter out = null;
/*    */     try {
/* 16 */       fo = new File(path);
/* 17 */       if (fo.exists())
/*    */       {
/* 19 */         fo.delete();
/*    */       }
/*    */       
/* 22 */       fo.createNewFile();
/*    */       
/* 24 */       out = new PrintWriter(path, "UTF-8");
/*    */       
/* 26 */       out.print(str);
/*    */     }
/* 28 */     catch (FileNotFoundException e1) {
/*    */       
/* 30 */       e1.printStackTrace();
/* 31 */       return false;
/* 32 */     } catch (NullPointerException ee) {
/* 33 */       ee.printStackTrace();
/* 34 */       return false;
/* 35 */     } catch (IOException e) {
/* 36 */       e.printStackTrace();
/* 37 */       return false;
/*    */     } finally {
/*    */       try {
/* 40 */         out.close();
/* 41 */       } catch (Exception e) {
/* 42 */         e.printStackTrace();
/*    */       } 
/*    */     } 
/*    */     
/*    */     try {
/* 47 */       out.close();
/* 48 */     } catch (Exception e) {
/* 49 */       e.printStackTrace();
/*    */     } 
/*    */     
/* 52 */     return ok;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public static void delFolder(String folderPath) {
/*    */     try {
/* 59 */       delAllFile(folderPath);
/* 60 */       String filePath = folderPath;
/* 61 */       filePath = filePath.toString();
/* 62 */       File myFilePath = new File(filePath);
/* 63 */       myFilePath.delete();
/* 64 */     } catch (Exception e) {
/* 65 */       e.printStackTrace();
/*    */     } 
/*    */   }
/*    */ 
/*    */   
/*    */   public static boolean delAllFile(String path) {
/* 71 */     boolean flag = false;
/* 72 */     File file = new File(path);
/* 73 */     if (!file.exists()) {
/* 74 */       return flag;
/*    */     }
/* 76 */     if (!file.isDirectory()) {
/* 77 */       return flag;
/*    */     }
/* 79 */     String[] tempList = file.list();
/* 80 */     File temp = null;
/* 81 */     for (int i = 0; i < tempList.length; i++) {
/* 82 */       if (path.endsWith(File.separator)) {
/* 83 */         temp = new File(String.valueOf(path) + tempList[i]);
/*    */       } else {
/* 85 */         temp = new File(String.valueOf(path) + File.separator + tempList[i]);
/*    */       } 
/* 87 */       if (temp.isFile()) {
/* 88 */         temp.delete();
/*    */       }
/* 90 */       if (temp.isDirectory()) {
/* 91 */         delAllFile(String.valueOf(path) + File.separator + tempList[i]);
/* 92 */         delFolder(String.valueOf(path) + File.separator + tempList[i]);
/* 93 */         flag = true;
/*    */       } 
/*    */     } 
/* 96 */     return flag;
/*    */   }
/*    */ }


/* Location:              /Users/harry/Documents/work/GBGame/Dragon/Doc/ExcelToCsv.jar!/net/cootek/csv/FileUtils.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */